const express = require('express')
const app = express()

// var preProcess = require('./process/preprocess')
//var postProcess = require('./process/postprocess')



const multer = require('multer')
const form_data = multer()

const cors = require('cors')

const dfd = require("danfojs-node")
const fs = require('fs')

let corsOption = {
    origin: 'http://localhost:8080',
    credentials: true
}

app.use(form_data.array())
app.use(express.urlencoded({ extended: false }));
app.use(express.json());

app.use(cors(corsOption))



let rootRecord = null
let lastSection = null,
    lastClass = null,
    lastSubClass = null,
    lastMainGroup = null,
    lastSubGroup = [null,null,null,null,null,null]

let resultArray = []
    sectionNumArray = [0,0,0,0,0,0,0,0,0,0]

// 레코드 클래스 선언. 선언된 생성자는 레코드 하나를 가리킨다.
class Record{
    constructor(code = null, description = null, descriptionToken = null, child = null, nextRecord = null, totalNumLowerClasses = 1){
        this.code = code
        this.description = description
        this.descriptionToken = descriptionToken
        this.child = child
        this.nextRecord = nextRecord
        this.totalNumLowerClasses = totalNumLowerClasses
    }
}

async function insertSection(line){
    const descriptionToken = tokenizeDescription(line[2])
    let record = new Record(line[0], line[2], descriptionToken)
    if(lastSection == null){
        rootRecord = record
        lastSection = record
    }
    else
        lastSection.nextRecord = record
    
    lastSection = record
}

async function insertClass(line){
    const descriptionToken = tokenizeDescription(line[2])
    let record = new Record(line[0], line[2], descriptionToken)
    if(lastSection.child == null)
        lastSection.child = record
    else
        lastClass.nextRecord = record

    lastClass = record
}
async function insertSubClass(line){
    const descriptionToken = tokenizeDescription(line[2])
    let record = new Record(line[0], line[2], descriptionToken)
    if(lastClass.child == null)
        lastClass.child = record
    else
        lastSubClass.nextRecord = record

    lastSubClass = record
    
}
async function insertMainGroup(line){
    const descriptionToken = tokenizeDescription(line[2])
    let record = new Record(line[0], line[2], descriptionToken)
    if(lastSubClass.child == null)
        lastSubClass.child = record
    else
        lastMainGroup.nextRecord = record
        
    
    lastMainGroup = record
}
async function insertSubGroup(line){
    const descriptionToken = tokenizeDescription(line[2])
    let record = new Record(line[0], line[2], descriptionToken)
    if(lastMainGroup.child == null)
        lastMainGroup.child = record
    else
        lastSubGroup[0].nextRecord = record
    
    
    lastSubGroup[0] = record
}

async function insertSubGroup_Above(line){
    const descriptionToken = tokenizeDescription(line[2])
    let record = new Record(line[0], line[2], descriptionToken)
    if(lastSubGroup[line[1]-2].child == null)
        lastSubGroup[line[1]-2].child = record
    else
        lastSubGroup[line[1]-1].nextRecord = record
    
    lastSubGroup[line[1]-1] = record
}

// 괄호 '(',')' 안의 내용을 제거하는 알고리즘. 
// 스택 구조를 이용하여 chrArr에 description을 문자 단위로 자른 것을
// 하나하나씩 push로 넣고 ')' 일때 바로 전 '('를 만날때까지 전부 하나하나씩 pop 해서 제거한다. 
// 완료 후 배열을 join을 통해 문장으로 전환한다. 
function EraseBracketInDescription(description){
    const descriptionArr = description.split("")
    let refinedDescription = null
        chrArr = [],
        numBracket = 0
    
    for([idx, chr] of descriptionArr.entries()){
        chrArr.push(chr)
        if(chr === '(')
          numBracket += 1
        else if(chr === ')'){
            if(numBracket != 0){
              while(true) {
                if(chrArr.pop() === '(')
                  break
              }
              numBracket -= 1
            }
        }
    }
    
    refinedDescription = chrArr.join('')
  
    return refinedDescription
  
}

function tokenizeDescription(description){
    // () 괄호 안의 문자열을 자르고 스트링화 시킨 후 대문자화 한다.
    // 대문자화는 후에 검색어와 비교할 때 대소문자를 구분하지 않기 위한 방법이다.
    const refineDescription = EraseBracketInDescription(description).toString()
                                .toUpperCase()
    // (\W: _를 제외한 특수문자) (\s: 공백 하나) 그리고 정규식 패턴 \W\s_ 이 여러개 나오면 
    // 연결된 문자열을 " "로 변경  
    // 그리고 trim 으로 맨 앞 뒤의 공백을 없앤 후 " "를 기준으로 토큰화
    const descriptionToken = refineDescription.replace(/[\W\s_]+/gi," ")
                                .trim()
                                .split(" ")
                                
    // console.log("token : ",token)
    return descriptionToken
}

// 전체 CPC 데이터에서 각 레코드마다 CPC 코드를 분류하여 계층을 나눈 후 데이터 트리에 구조화
// 하는 함수를 실행한다
async function structRecordTree(items){
    const regex_Section = new RegExp('^[A-Z]$')
    const regex_Class = new RegExp('^[A-Z][0-9]{2}$')
    const regex_SubClass = new RegExp('^[A-Z][0-9]{2}[A-Z]$')
    const regex_MainGroup = new RegExp('^[A-Z][0-9]{2}[A-Z][0-9]{1,4}/00$')
    const regex_SubGroup = new RegExp('^[A-Z][0-9]{2}[A-Z][0-9]{1,4}/[0-9]{2,6}$')
    
    for(item of items){
        for( [idx,line] of item.entries()){
            if(regex_Section.test(line[0])){
                await insertSection(line)
            }
            else if(regex_Class.test(line[0])){
                await insertClass(line)
            }
            else if(regex_SubClass.test(line[0])){
                await insertSubClass(line)
            }
            else if(regex_MainGroup.test(line[0])){
                await insertMainGroup(line)
            }
            else if(regex_SubGroup.test(line[0])){    
                if(line[1] == 1){
                    await insertSubGroup(line)
                }
                else if(line[1] > 1){
                    await insertSubGroup_Above(line)
                }
            }
        }
    }

}

// 하위 계층 레코드의 수를 계산.
// 재귀적으로 호출하여 stack을 쌓아 맨 마지막으로 호출된 마지막 레코드부터 
// 레코드가 가지고 있는 하위 계층 레코드의 합을 상위 계층으로 return 하고 그 값을 return 받은 레코드가
// 레코드 값을 갱신하고 다시 그 값을 상위 레코드에 전달해주는 방식이다.
async function setNumberLowerClassOfTree(record){
    let numChild = 0,
        numNextRecord = 0

    if(record != null){
        if(record.child != null)
        {    
            numChild = await setNumberLowerClassOfTree(record.child)
        }
        if(record.nextRecord != null){
            numNextRecord = await setNumberLowerClassOfTree(record.nextRecord)
        }

        record.totalNumLowerClasses = record.totalNumLowerClasses + numChild 

        return record.totalNumLowerClasses + numNextRecord
    }

}



// CPC 엑셀 파일을 읽어들여 연결리스트 형태의 트리 구조화하는 루틴
function readXLS(){
    let cpcItems = [],
        file_idx = 0
    //파일을 읽어들여 fileList형태로 저장
    fs.readdir(process.cwd()+"/public/cpc", function(error, fileList){
        // fileList에는 파일명의 목록이 저장되고 forEach로 local_xcel에 각각의 파일명을 전달한다.
        fileList.forEach(async (local_xcel)=>{
            file_idx++
            // 파일 인덱스가 10(마지막 섹션)이 아니면 파일을 계속 읽어들여 cpcItems(CPC 데이터의 저장공간)에 푸쉬한다.
            if(file_idx != 10){
                let readFile = await dfd.read_excel(process.cwd()+"/public/cpc/"+local_xcel).then((readFile)=>{
                    cpcItems.push(readFile.$data)
                })
            }
            // 파일 인덱스가 10(마지막 섹션)이면 연속적 콜백 구조로 동기적인 데이터 세팅 루틴을 실행한다. - structRecordTree
            // 먼저 전제 레코드들을 트리 구조화한 후 트리에 존재하는 각각의 레코드에 하위계층 데이터의 수를 세팅하여
            // 레코드 구조를 완성한다.  - setNumberLowerClassOfTree
            else if(file_idx == 10){
                let readFile = await dfd.read_excel(process.cwd()+"/public/cpc/"+local_xcel).then((readFile)=>{
                    cpcItems.push(readFile.$data)
                }).then(()=>{
                    console.log("1.readXLS()")
                    structRecordTree(cpcItems).then(()=>{
                        console.log("2.structRecordTree()")
                        console.log(rootRecord.code, "  ", rootRecord.child.nextRecord.descriptionToken)
                        setNumberLowerClassOfTree(rootRecord).then(()=>{
                            console.log("3.setNumberLowerClassOfTree")
                            console.log("4.rootRecord:", rootRecord)
                            console.log("--- Read Success XLS Files ---")
                        })
                    })
                })
            }
            
        })
        
    })

    return rootRecord
}

// 토큰 비교 알고리즘

// 검색어토큰(keywordToken)을 전부 포함하는 레코드(descriptionToken)가 있으면 
// true를 반환하고 아니면 false를 반환한다.
// 비교하는 방법은 각 keywordToken마다 descriptionToken의 토큰들을 1:1 비교하여
// 존재유무가 확인되면 다음 keywordToken을 비교하고 없으면 false를 반환한다.
// 모든 사이클을 통과했을 시에는 검색어들을 전부 포함하고 있다는 뜻이므로 true를 반환한다.

async function searchKeywordInDescription(keywordToken, descriptionToken) {

    const keywordTokenLen = keywordToken.length
    let searchedNum = 0 

    for (keyword of keywordToken){ 
        for (description of descriptionToken){
            if(keyword === description){
                searchedNum +=1 
                break
            }
        }
        if(searchedNum === keywordTokenLen)
            return true
    }
    
    return false
}

function SectionNumCalculation(chr){
    if(chr ==='A')
        sectionNumArray[0] += 1
    else if(chr === 'B')
        sectionNumArray[1] += 1
    else if(chr === 'C')
        sectionNumArray[2] += 1
    else if(chr === 'D')
        sectionNumArray[3] += 1
    else if(chr === 'E')
        sectionNumArray[4] += 1
    else if(chr === 'F')
        sectionNumArray[5] += 1
    else if(chr === 'G')
        sectionNumArray[6] += 1
    else if(chr === 'H')
        sectionNumArray[7] += 1
    else if(chr === 'Y')
        sectionNumArray[8] += 1
    else if(chr === 'Z')
        sectionNumArray[9] += 1
}

function initState(){
    resultArray = []
    sectionNumArray = [0,0,0,0,0,0,0,0,0,0]
}

function tokenizeKeyword(keyword){
  // (\W: _를 제외한 특수문자) (\s: 공백 하나) 그리고 정규식 패턴 \W\s_ 이 여러개 나오면 
  // 연결된 문자열을 " "로 변경  
  // 그리고 trim 으로 맨 앞 뒤의 공백을 없앤 후 대문자화(대소문자 구분을 없애고 비교하기 위해)
  // 를 진행하고 " "를 기준으로 토큰화
  // 즉 결과적으로 모든 특수문자 및 공백이 제거된 단어들로 토큰 배열을 return한다.
  const keywordToken = keyword.replace(/[\W\s_]+/gi," ")
                        .trim()
                        .toUpperCase()
                        .split(" ")

  console.log("token : ",keywordToken)
  return keywordToken
}

// 레코드 트리에서 조건 전위 탐색으로 데이터를 찾는다.
// 동일 계층은 다음 동일 계층 레코드를 참조하고 각 레코드마다 직속 하위계층 연결리스트의 첫 레코드 주소를 참조한다.
// 만약 searchKeywordInDescription을 실행하여 검색어를 포함하고 있으면 flag를 true로 하여 하위 계층을 검색하게
// 되고 만약 포함하지 않으면 리스트로 참조된 동일 계층의 레코드를 검색한다.

async function recordTreePreOrderSearch(keywordToken, record){
    let flag = false
    if(record != null){
        if(await searchKeywordInDescription(keywordToken, record.descriptionToken)){
            console.log(record.code, " ", record.totalNumLowerClasses, " ", record.descriptionToken)

            await SectionNumCalculation(record.code[0])
            await resultArray.push([record.code, record.totalNumLowerClasses, record.description])
            flag = true
        }
        if(record.child != null && flag == false){
            await recordTreePreOrderSearch(keywordToken, record.child)
        }
        if(record.nextRecord != null){
            await recordTreePreOrderSearch(keywordToken, record.nextRecord)
        }
        
    }
}

async function sendSearchedRecords(keywordToken, rootRecord) {
    
    await recordTreePreOrderSearch(keywordToken, rootRecord)
    let resData = {
        data: resultArray,
        totalPerSec: sectionNumArray 
    }
    
    let resJsonEncode = JSON.stringify(resData)
    //console.log(resJsonEncode)
    return resJsonEncode
    
}
/// 임시 전처리 영역 ------------->

readXLS()
  

///  <------------ 임시 전처리 영역


// 포트 3000번 사용
app.listen(3000, function(){
    console.log("port 3000 server start")
})


// request 요구한 검색어에 대한 레코드들을 전송하는 api
app.post('/api/cpcItems', async function(req, res, nxt){
    console.log("receive req : ", req.body.keyword)
    await initState()
    let keywordToken = await tokenizeKeyword(req.body.keyword)
    
    let resJsonEncode = await sendSearchedRecords(keywordToken, rootRecord)
    
    await res.send(resJsonEncode)
})


// 임시
app.post('/api',function(req, res, nxt){
    console.log("receive root req")
    res.send("root acc succ")
})